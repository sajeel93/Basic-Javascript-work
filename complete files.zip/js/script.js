function box() {
	
	alert("Hi! Are you a Web Developer?");
	y = window.confirm("r u sure");

	if(y) {
		alert("OK");
		}

	else { alert("cancle")
	}	
	
}

function box2() {

	 a = confirm("Are you ready to visit on facebook ?");

	if(a) {
		open("https://www.facebook.com/siasatpakistanofficial/");
	}
	else {

		document.write("You select <u>cencle</u>, Please refresh again this page");
	}
}


function pa(first,second) {

	alert("Hi! " + first + " " + second );
}

function pa2(age) {

	alert("I'm " + age + " year old");
}


function ifelseif() {
	
	a = parseInt(prompt("Enter 1st number"));
	b = parseInt(prompt("Enter 2st number"));
	c = parseInt(prompt("Enter 3st number"));
	

	if(a>b && a>c){

		document.write("The Greater number is "+a);
	}

	else if (b>a && b>c) {

		document.write("The Greater number is "+b);
	}

	else if (c>a && c>b) {

		document.write("The Greater number is "+c);
	}

	else {
		document.write("All numbers are equal");
	}
}

function switchexemple() {

	a = parseInt(prompt("Plz Enter first integer value for calculation"));
	b = parseInt(prompt("Plz Enter second integer value for calculation"));
	c = prompt("Plz Enter integer your operational symbul fron + : - : * : /");

	switch (c){

		case "+" :
			 c = a + b;
			 document.write("Your answer is "+c);
			 break;

		case "-" :
			 c = a - b;
			 document.write("Your answer is "+c);
			 break;

		case "*" :
			 c = a * b;
			 document.write("Your answer is "+c);
			 break;

		case "/" :
			 c = a / b;
			 document.write("Your answer is "+c);
			 break;	

		default :
			 document.write("your input is not valid, plz try again");	

	}
}


function forloop(){

	var a;

	for(a=1; a<10; a++) {

		document.write("Your nuber is " +a+ "<br>")
	}
}

function forloop2(){

	var a;

	for(a=3; a<90; a+=3) {
		
		document.write("Your nuber is = " +a+ "<br>")
	}
}

function forloop3(){

	var abc = 10;

	for(xyz=1; xyz<10; xyz++) {
		
		document.write("Ten table with different coding  " +abc+ " * " +xyz+ " = " + abc*xyz + "<br>")
	}
}

function whileloop() {

	var a = 0;

	while(a<=10) {

		a++;

		document.write("This line is repeating through While loop " +a+ "<br>")
	}
}


function whileloop2() {

	first = 10;
	second = 0;

	while(second<=10) {

		second++;

		document.write("this values are multipling through while loop" + first * second + "<br>")
	}
}


function dowhileloop() {

	a = 5;

	do {

		a++;

		document.write("This loop at-least 1 time repeat through do-wwhile with wrong Condition " +a+ "<br>")

	}
	while(a<10)
}

function array123() {

	var fruits = ["Mango","Orange","Grapes","Banana"];

	var cars   = ["Saab", "Volvo", "BMW"];


	document.write(fruits[0] + "<br>");

	document.write(cars);
}

function array456() {

	var fruits = new Array("Orange", "Banana", "Mango");
	document.getElementById('demo10').innerHTML = fruits[2];
}

function array789() {

	var fruits = new Array("Orange", "Banana", "Mango");

	document.write(fruits[1]);
}

function object1() {

	var person = new Object("Sajeel","Student","pakistan");

	document.write(person[0] + person[1] + person[2]);
}

function object2() {

	var person = {

		name : 'Sajeel',
		Age  : 23,
		Country : 'pakistan'
	};

	document.write("My name is " + person['name'] + "<br>  I'm " + person['Age'] + "Year old, <br> I lived in " + person['Country']);

	document.write("<br>");
	document.write(person['Age']);

	document.write("<br>");
	document.write(person.name);

	document.write("<br>");
	document.write(person.Country);
}


function method1() {

	var myhouse = new Object();
	myhouse.length = 60;
	myhouse.width  = 50;
	myhouse.area   = function() {

		return this.length * this.width
	} 

	var urhouse = {

		length : 85,
		width  : 45,
		area   : function() {

		 return	this.length * this.width
		}
	}


document.write(urhouse.area());

}

function method2() {

	Area = function(){

		return this.length + this.width
	}

	var myhouse = new Object();
	myhouse.length = 60;
	myhouse.width  = 50;

	var urhouse = {

		length : 85,
		width  : 45,
	}	

	document.write(urhouse.area());
}